package com.example.fap_grp7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
